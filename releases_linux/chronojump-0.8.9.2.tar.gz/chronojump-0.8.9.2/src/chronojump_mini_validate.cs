/***********************************************************
 * chronojump_mini_validate    
 * Juan Gonzalez Gomez. Febrero 2005
 * Xavier de Blas Foix. Febrero 2007
 *---------------------------------------------------------
 * Records contact time and flight time at jumps           
 * Prints results in a text file
 * This text file will be converted to csv by another utility
 * It's done for managing an evaluation with lots of input from:
 * -square waves generator
 * -oscilloscope
 * Licencia GPL                                            
/***********************************************************/
/*------------------------------------------------------------------------
  $Id: 
  $Revision: 
  $Source: 
  --------------------------------------------------------------------------*/

using System;
using System.IO.Ports;
using System.IO; 	//TextWriter
using System.Text; //StringBuilder

using Mono.Unix;

class Test {

	static TextWriter writer;

	//-- Estado del automata
	enum Automata {
		ON,
		OFF
	}

	/**********************/
	/* PROGRAMA PRINCIPAL */
	/**********************/
	public static void Main()
	{
		Chronopic.Plataforma estado_plataforma;
		Automata estado_automata;
		double timestamp;
		double toff;
		double ton;
		bool ok;

		System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("es-ES");
		System.Threading.Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo("es-ES");
		
		//connect with catalog.cs for using gettext translation
		Catalog.Init ("chronojump", "./locale");

		string messageInfo;
		string messageDetected ="";

		if(Util.IsWindows()) {
			messageInfo = Constants.PortNamesWindows;
			/*
			   messageDetected = Catalog.GetString("Detected ports:") + "\n";

			   string jumpLine = "";
			   foreach (string s in SerialPort.GetPortNames()) {
			   messageDetected += jumpLine + s;
			   jumpLine = "\n";
			   }
			   */
		} else {
			messageInfo = Constants.PortNamesLinux;

			//messageDetected = string.Format(Catalog.GetString("Auto-Detection currently disabled on GNU/Linux"));
		}

//		DateTime myDate = new DateTime();
//		string dataDir = myDate.Now.ToString();
		string dataDir = DateTime.Now.ToString();
		StringBuilder myStringBuilder = new StringBuilder(dataDir);
		myStringBuilder.Replace("/", "-");
		myStringBuilder.Replace(":", "-");
		myStringBuilder.Replace(" ", "_");
		dataDir = myStringBuilder.ToString();
		Console.WriteLine(dataDir);

		if(!Directory.Exists(dataDir)) {
			Directory.CreateDirectory (dataDir);
		}

		Console.WriteLine();

		messageInfo += string.Format(Catalog.GetString("More information on Chronojump manual"));

		messageDetected = string.Format(Catalog.GetString("Auto-Detection currently disabled"));

		Console.WriteLine("---------------------------");
		Console.WriteLine(messageInfo);
		Console.WriteLine("---------------------------");
		Console.WriteLine(messageDetected);
		Console.WriteLine("---------------------------\n");
		Console.WriteLine(Catalog.GetString("Print the port name where chronopic is connected:"));

		string portName=Console.ReadLine();

		Console.WriteLine(Catalog.GetString("Opening port... if get hanged, generate events with chronopic or the platform"));
		//-- Crear puerto serie		
		SerialPort sp;
		sp = new SerialPort(portName);

		//-- Abrir puerto serie. Si ocurre algun error
		//-- Se lanzara una excepcion
		try {
			sp.Open();
		} catch (Exception e){
			Console.WriteLine(Catalog.GetString("Error opening serial port"));
			Console.WriteLine(e);
			Environment.Exit(1);
		}

		//-- Crear objeto chronopic, para acceder al chronopic
		Chronopic cp = new Chronopic(sp);


		//-- Obtener el estado inicial de la plataforma
		// this do...while is here because currently there's no timeout on chronopic.cs on windows
		do {
			ok=cp.Read_platform(out estado_plataforma);
		} while(!ok);
		if (!ok) {
			//-- Si hay error terminar
			Console.WriteLine(string.Format(Catalog.GetString("Error: {0}"),cp.Error));
			System.Environment.Exit(-1);
		}
		Console.WriteLine(string.Format(Catalog.GetString("Platform state: {0}"), estado_plataforma));


		//-- Establecer el estado inicial del automata
		if (estado_plataforma==Chronopic.Plataforma.ON) 
			estado_automata=Automata.ON;
		else {
			/*
			Console.WriteLine(Catalog.GetString("Go up platform for jumping"));

			//-- Esperar a que llegue una trama con el estado de la plataforma
			//-- igual a ON. Esto indica que el usuario se ha subido
			do {
				ok = cp.Read_event(out timestamp, out estado_plataforma);
			} while (!ok);

			//-- Se han subido a la plataforma
			estado_automata = Automata.ON;
			*/
			estado_automata=Automata.OFF;
		}

		Console.WriteLine("");
		//Console.WriteLine(Catalog.GetString("Jump when prepared"));
		//Console.WriteLine(Catalog.GetString("Press CTRL-c for ending session"));
		Console.WriteLine("-----------------------------------------");

		string printData = "";
		double tcCount = 0;
		double tfCount = 0;

		while(true) {
			/*
			Console.WriteLine("Print freq (square waves generator) ('-1' to exit)");
			string square=Console.ReadLine();
			if (square == "-1")
				break;
			*/
			Console.WriteLine("Print freq (oscilloscope generator) ('-1' to exit)");
			string oscilloscope=Console.ReadLine();
			if (oscilloscope == "-1")
				break;
			
			//string testFile = dataDir + "/" + square + "-" + oscilloscope;
			string testFile = dataDir + "/" + oscilloscope;

			writer = File.CreateText(testFile);
			
			Console.WriteLine("Print number of waves for this test");
			int waves = Convert.ToInt32(Console.ReadLine());
			Console.WriteLine("Estimated time: {0}s", (waves * 1/Convert.ToDouble(oscilloscope)).ToString());

			cp.Flush();

			for (int count=0; count <= waves * 2; count ++) {
				//-- Esperar a que llegue una trama
				do {
					ok = cp.Read_event(out timestamp, out estado_plataforma);
				} while (ok==false);


				//-- Segun el estado del automata
				switch(estado_automata) {

					case Automata.OFF: //-- Usuario estaba en el aire

						//-- Si ha aterrizado
						if (estado_plataforma==Chronopic.Plataforma.ON) {

							//-- Pasar al estado ON
							estado_automata=Automata.ON;

							//-- Registrar tiempo de vuelo
							toff = timestamp;
							tfCount += timestamp;

							//-- Imprimir informacion
							printData = string.Format("{0}:TF:{1:f1}", count, toff);
							Console.WriteLine(printData);
							writer.WriteLine(printData);
						}
						break;

					case Automata.ON: //-- Usuario estaba en la plataforma

						//-- Si ahora esta en el aire...
						if (estado_plataforma==Chronopic.Plataforma.OFF) {

							//-- Pasar al estado OFF
							estado_automata=Automata.OFF;

							//-- Registrar tiempo de contacto
							ton = timestamp;
							tcCount += timestamp;

							//-- Imprimir informacion
							printData = string.Format("{0}:TC:{1:f1}", count, ton);
							Console.WriteLine(printData);
							writer.WriteLine(printData);

						}
						break;
				}

			}
			
			printData = string.Format("AVG:TC:{0:f1}", tcCount / waves);
			Console.WriteLine(printData);
			writer.WriteLine(printData);
			printData = string.Format("AVG:TF:{0:f1}", tfCount / waves);
			Console.WriteLine(printData);
			writer.WriteLine(printData);

			//closeWriter();
			((IDisposable)writer).Dispose();
		}
	}

/*
	protected void closeWriter ()
	{
		((IDisposable)writer).Dispose();
	} 
*/

}
