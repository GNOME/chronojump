Images here should have the same name as parent dir, and should have 150px wide

no_image.png is a special image that should not be in parent directory
