---------------------------------------------------------------------------------
                  Microchip PIC16F87x Bootloader/Downloader
---------------------------------------------------------------------------------

How to use the bootloader/downloader: 

1. Open bootldr.pjt file in the Microchip MPLAB and change the parameters of 
   the User setting section.

2. Recompile bootldr.asm.

3. Program microcontroller with bootldr.hex file. Set your config bits.

4. Recompile your program so it doesn't overwrite the bootloader.  The bootloader 
   uses 256 bytes at the top of program memory. For Hi-Tech C, add -ICD to the PICC options.
   Check if goto instruction after reset is long jump because 1st 4 address will be
   relocated to other bank.

   Microchip PIC 16F876/877 memory map with the bootloader installed

  Address
  0x0000 ---------------------------- 
         |   Jump to bootloader     |	<--- Bootloader uses 1st 4 words (0x0000-0x0003)
  0x0004 |--------------------------|
	 |                          |
	 |                          |
	 |                          |
	 |                          |
	 |                          |
	 |                          |
	 |      Program space       |
	 |      available for       |	<--- Available space for user programs
	 |   downloaded programs    |
	 |                          |
	 |                          |
	 |                          |
	 |                          |
	 |                          |
	 |                          |
	 |                          |
  0x1F00 |--------------------------|
	 |   Jump to user program   |	<--- 1st 4 user program words (0x1F00-0x1F03)
  0x1F04 |--------------------------|
	 |                          |
	 |     Bootloader code      |	<--- The bootloader code (0x1F04-0x1FFF)
	 |                          |
  0x1FFF ----------------------------

5. Plug in a serial interface with a MAX232 etc to connect the serial port of 
   the computer to pins RX/TX (option RESET/Trigger pin) on microcontroller.
   RESET       - RTS
   Trigger pin - DTR

6. Run "PIC downloader.exe", and choose baud rate, com port, write eeprom and 
   the .hex file to download.
   Function keys:
   F2 - Search
   F4 - Write
   ESC - Cancel
   F10 - exit

7. Click "Write" and reset manual PIC, the program is downloaded into the PIC micro.

8. Reset the PIC after complete download. Your program will start.

Notes:
-the bootloader/downloader is compatible with HI-TECH's (www.htsoft.com) and Shane Tolmie's
 (www.workingtex.com/htpic) bootloader/downloader
-the bootloader is rewritten and modified HI-TECH's bootloader from C to assembler 

(c) 2000 Petr Kolomaznik
Email: kolomaznik@ehl.cz
Url:   http://www.ehl.cz/pic
